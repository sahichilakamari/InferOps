import { pgTable, serial, text, integer, real, timestamp } from "drizzle-orm/pg-core";

export const incidents = pgTable("incidents", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  severity: text("severity").notNull().default("medium"),
  status: text("status").notNull().default("active"),
  affectedServices: text("affected_services").notNull().default("[]"),
  rootCause: text("root_cause"),
  startedAt: timestamp("started_at").notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at"),
  errorRate: real("error_rate"),
  peakCpuUsage: real("peak_cpu_usage"),
});

export const timelineEvents = pgTable("timeline_events", {
  id: serial("id").primaryKey(),
  incidentId: integer("incident_id").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  message: text("message").notNull(),
  eventType: text("event_type").notNull(),
  service: text("service"),
  metadata: text("metadata"),
});

export const incidentAnalyses = pgTable("incident_analyses", {
  id: serial("id").primaryKey(),
  incidentId: integer("incident_id").notNull(),
  rootCause: text("root_cause").notNull(),
  confidence: real("confidence").notNull(),
  severity: text("severity").notNull(),
  affectedServices: text("affected_services").notNull().default("[]"),
  remediation: text("remediation").notNull().default("[]"),
  explanation: text("explanation").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const postmortems = pgTable("postmortems", {
  id: serial("id").primaryKey(),
  incidentId: integer("incident_id").notNull(),
  summary: text("summary").notNull(),
  rootCause: text("root_cause").notNull(),
  impact: text("impact").notNull(),
  timeline: text("timeline").notNull(),
  resolution: text("resolution").notNull(),
  prevention: text("prevention").notNull().default("[]"),
  markdownContent: text("markdown_content"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const logEntries = pgTable("log_entries", {
  id: serial("id").primaryKey(),
  logId: text("log_id").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  severity: text("severity").notNull(),
  service: text("service").notNull(),
  message: text("message").notNull(),
  incidentId: integer("incident_id"),
});

export const chatConversations = pgTable("chat_conversations", {
  id: text("id").primaryKey(),
  title: text("title"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const chatMessages = pgTable("chat_messages", {
  id: text("id").primaryKey(),
  conversationId: text("conversation_id").notNull(),
  role: text("role").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
