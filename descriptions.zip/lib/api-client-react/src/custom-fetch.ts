/**
 * Custom Fetch Implementation for InferOps API Client
 *
 * Features:
 * - Type-safe HTTP client with full TypeScript support
 * - Automatic request/response parsing (JSON, text, blob)
 * - Bearer token authentication support
 * - Dynamic base URL configuration for Expo/React Native
 * - Comprehensive error handling with structured error objects
 * - Runtime compatibility (browser, Node.js, React Native, Expo)
 */

// ============================================================================
// Type Definitions
// ============================================================================

/**
 * Extended fetch options with custom response type handling
 * @example
 * customFetch('/api/users', {
 *   method: 'POST',
 *   body: JSON.stringify({ name: 'John' }),
 *   responseType: 'json',
 *   headers: { 'X-Custom-Header': 'value' }
 * })
 */
export type CustomFetchOptions = RequestInit & {
  /**
   * How to parse the response body
   * - 'json': Parse as JSON object
   * - 'text': Parse as plain text
   * - 'blob': Get raw Blob
   * - 'auto': Infer from Content-Type header (default)
   */
  responseType?: "json" | "text" | "blob" | "auto";
};

/** Generic error type for API errors */
export type ErrorType<T = unknown> = ApiError<T>;

/** Generic body type for request payloads */
export type BodyType<T> = T;

/**
 * Function that provides bearer authentication tokens
 * Called before each request to get the current auth token
 * @returns Promise or direct return of token string, or null if not authenticated
 * @example
 * setAuthTokenGetter(() => localStorage.getItem('auth_token'))
 * setAuthTokenGetter(async () => {
 *   const response = await fetch('/auth/token');
 *   return response.json().then(data => data.token);
 * })
 */
export type AuthTokenGetter = () => Promise<string | null> | string | null;

// ============================================================================
// Constants
// ============================================================================

/** HTTP status codes that should not have a response body */
const NO_BODY_STATUS = new Set([204, 205, 304]);

/** Default Accept header for JSON responses */
const DEFAULT_JSON_ACCEPT = "application/json, application/problem+json";

// ============================================================================
// Module-Level Configuration
// ============================================================================

/** Configured base URL for relative requests */
let _baseUrl: string | null = null;

/** Configured auth token getter function */
let _authTokenGetter: AuthTokenGetter | null = null;

/**
 * Configure a base URL for relative requests
 *
 * When set, all relative paths (starting with `/`) will be prepended with
 * this URL. Useful for mobile apps (Expo, React Native) calling a remote API.
 *
 * @param url - Base URL (e.g., 'https://api.example.com') or null to clear
 * @example
 * // In Expo app
 * setBaseUrl('https://api.inferops.com');
 * // Now: customFetch('/incidents') → fetch('https://api.inferops.com/incidents')
 */
export function setBaseUrl(url: string | null): void {
  _baseUrl = url ? url.replace(/\/+$/, "") : null;
}

/**
 * Register a function that provides bearer authentication tokens
 *
 * The getter is called before every request. If it returns a non-null string,
 * an `Authorization: Bearer <token>` header is automatically added.
 *
 * ⚠️ Do NOT use this in browser applications with session cookies.
 * Session tokens are automatically sent by the browser.
 *
 * @param getter - Function returning a token or null, or null to clear
 * @example
 * // With Expo SecureStore
 * setAuthTokenGetter(async () => {
 *   return SecureStore.getItemAsync('auth_token');
 * });
 *
 * // With localStorage
 * setAuthTokenGetter(() => localStorage.getItem('token'));
 */
export function setAuthTokenGetter(getter: AuthTokenGetter | null): void {
  _authTokenGetter = getter;
}

// ============================================================================
// Type Guards & Input Resolution
// ============================================================================

/**
 * Check if input is a Request object
 */
function isRequest(input: RequestInfo | URL): input is Request {
  return typeof Request !== "undefined" && input instanceof Request;
}

/**
 * Resolve HTTP method from various input types
 * Precedence: explicit method > Request.method > "GET"
 */
function resolveMethod(input: RequestInfo | URL, explicitMethod?: string): string {
  if (explicitMethod) return explicitMethod.toUpperCase();
  if (isRequest(input)) return input.method.toUpperCase();
  return "GET";
}

/**
 * Check if input is a URL object
 * Uses loose type checking for runtime compatibility
 */
function isUrl(input: RequestInfo | URL): input is URL {
  return typeof URL !== "undefined" && input instanceof URL;
}

/**
 * Extract URL string from various input types
 */
function resolveUrl(input: RequestInfo | URL): string {
  if (typeof input === "string") return input;
  if (isUrl(input)) return input.toString();
  return input.url;
}

// ============================================================================
// URL & Base URL Handling
// ============================================================================

/**
 * Apply configured base URL to relative paths
 * Only prepends to paths starting with `/`
 * Preserves absolute URLs and external resources
 */
function applyBaseUrl(input: RequestInfo | URL): RequestInfo | URL {
  if (!_baseUrl) return input;

  const url = resolveUrl(input);
  // Only prepend to relative paths (starting with /)
  if (!url.startsWith("/")) return input;

  const absolute = `${_baseUrl}${url}`;

  // Preserve input type
  if (typeof input === "string") return absolute;
  if (isUrl(input)) return new URL(absolute);
  return new Request(absolute, input as Request);
}

// ============================================================================
// Header Handling
// ============================================================================

/**
 * Merge multiple header sources into a single Headers object
 * Later sources override earlier ones
 */
function mergeHeaders(...sources: Array<HeadersInit | undefined>): Headers {
  const headers = new Headers();

  for (const source of sources) {
    if (!source) continue;
    new Headers(source).forEach((value, key) => {
      headers.set(key, value);
    });
  }

  return headers;
}

/**
 * Extract media type from Content-Type header
 * Returns the type without parameters (e.g., 'application/json' from 'application/json; charset=utf-8')
 */
function getMediaType(headers: Headers): string | null {
  const value = headers.get("content-type");
  return value ? value.split(";", 1)[0].trim().toLowerCase() : null;
}

/**
 * Check if media type is JSON-based
 * Matches 'application/json' and types ending with '+json' (e.g., 'application/problem+json')
 */
function isJsonMediaType(mediaType: string | null): boolean {
  return mediaType === "application/json" || Boolean(mediaType?.endsWith("+json"));
}

/**
 * Check if media type is text-based
 * Includes plain text, XML, form data, etc.
 */
function isTextMediaType(mediaType: string | null): boolean {
  return Boolean(
    mediaType &&
      (mediaType.startsWith("text/") ||
        mediaType === "application/xml" ||
        mediaType === "text/xml" ||
        mediaType.endsWith("+xml") ||
        mediaType === "application/x-www-form-urlencoded"),
  );
}

// ============================================================================
// Response Body Detection
// ============================================================================

/**
 * Check if response should not have a body
 * Uses strict equality for React Native compatibility
 *
 * @remarks
 * In browsers: `response.body` is null when no content
 * In React Native: `response.body` is undefined even with content (no ReadableStream support)
 * We use strict equality (`===`) to distinguish between null (no body) and undefined (may have body)
 */
function hasNoBody(response: Response, method: string): boolean {
  if (method === "HEAD") return true;
  if (NO_BODY_STATUS.has(response.status)) return true;
  if (response.headers.get("content-length") === "0") return true;
  if (response.body === null) return true;
  return false;
}

// ============================================================================
// String Utilities
// ============================================================================

/**
 * Remove BOM (Byte Order Mark) from text if present
 * Some servers incorrectly send UTF-8 with BOM
 */
function stripBom(text: string): string {
  return text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;
}

/**
 * Check if text looks like JSON (heuristic)
 * Used for content-type inference when header is missing
 */
function looksLikeJson(text: string): boolean {
  const trimmed = text.trimStart();
  return trimmed.startsWith("{") || trimmed.startsWith("[");
}

/**
 * Extract and validate a string field from an object
 * Returns undefined if field is missing, not a string, or empty after trim
 */
function getStringField(value: unknown, key: string): string | undefined {
  if (!value || typeof value !== "object") return undefined;

  const candidate = (value as Record<string, unknown>)[key];
  if (typeof candidate !== "string") return undefined;

  const trimmed = candidate.trim();
  return trimmed === "" ? undefined : trimmed;
}

/**
 * Truncate text to a maximum length with ellipsis
 * Useful for error messages that might be very long
 */
function truncate(text: string, maxLength = 300): string {
  return text.length > maxLength ? `${text.slice(0, maxLength - 1)}…` : text;
}

// ============================================================================
// Error Message Building
// ============================================================================

/**
 * Build a descriptive error message from response and parsed body
 * Tries multiple common error field names (RFC 7807, custom formats, etc.)
 */
function buildErrorMessage(response: Response, data: unknown): string {
  const prefix = `HTTP ${response.status} ${response.statusText}`;

  // If body is plain text, use it directly
  if (typeof data === "string") {
    const text = data.trim();
    return text ? `${prefix}: ${truncate(text)}` : prefix;
  }

  // Try to extract error fields from structured responses
  const title = getStringField(data, "title");
  const detail = getStringField(data, "detail");
  const message =
    getStringField(data, "message") ??
    getStringField(data, "error_description") ??
    getStringField(data, "error");

  // Build message with available fields
  if (title && detail) return `${prefix}: ${title} — ${detail}`;
  if (detail) return `${prefix}: ${detail}`;
  if (message) return `${prefix}: ${message}`;
  if (title) return `${prefix}: ${title}`;

  return prefix;
}

// ============================================================================
// Error Classes
// ============================================================================

/**
 * Represents an HTTP error response from the API
 * Contains full request/response information for debugging and error handling
 */
export class ApiError<T = unknown> extends Error {
  readonly name = "ApiError";
  readonly status: number;
  readonly statusText: string;
  readonly data: T | null;
  readonly headers: Headers;
  readonly response: Response;
  readonly method: string;
  readonly url: string;

  constructor(
    response: Response,
    data: T | null,
    requestInfo: { method: string; url: string },
  ) {
    super(buildErrorMessage(response, data));
    Object.setPrototypeOf(this, new.target.prototype);

    this.status = response.status;
    this.statusText = response.statusText;
    this.data = data;
    this.headers = response.headers;
    this.response = response;
    this.method = requestInfo.method;
    this.url = response.url || requestInfo.url;
  }
}

/**
 * Represents a failure to parse a successful response
 * The response was 200-299 but the body couldn't be parsed as expected
 */
export class ResponseParseError extends Error {
  readonly name = "ResponseParseError";
  readonly status: number;
  readonly statusText: string;
  readonly headers: Headers;
  readonly response: Response;
  readonly method: string;
  readonly url: string;
  readonly rawBody: string;
  readonly cause: unknown;

  constructor(
    response: Response,
    rawBody: string,
    cause: unknown,
    requestInfo: { method: string; url: string },
  ) {
    super(
      `Failed to parse response from ${requestInfo.method} ${response.url || requestInfo.url} ` +
        `(${response.status} ${response.statusText}) as JSON`,
    );
    Object.setPrototypeOf(this, new.target.prototype);

    this.status = response.status;
    this.statusText = response.statusText;
    this.headers = response.headers;
    this.response = response;
    this.method = requestInfo.method;
    this.url = response.url || requestInfo.url;
    this.rawBody = rawBody;
    this.cause = cause;
  }
}

// ============================================================================
// Response Parsing
// ============================================================================

/**
 * Parse response body as JSON
 * Removes BOM and handles empty responses
 * @throws ResponseParseError if JSON is invalid
 */
async function parseJsonBody(
  response: Response,
  requestInfo: { method: string; url: string },
): Promise<unknown> {
  const raw = await response.text();
  const normalized = stripBom(raw);

  if (normalized.trim() === "") {
    return null;
  }

  try {
    return JSON.parse(normalized);
  } catch (cause) {
    throw new ResponseParseError(response, raw, cause, requestInfo);
  }
}

/**
 * Parse error response body
 * Intelligently handles JSON, text, and binary responses
 * Never throws - always returns parsed data or null
 */
async function parseErrorBody(response: Response, method: string): Promise<unknown> {
  if (hasNoBody(response, method)) {
    return null;
  }

  const mediaType = getMediaType(response.headers);

  // Fall back to text when blob() is unavailable (e.g., some React Native builds)
  if (mediaType && !isJsonMediaType(mediaType) && !isTextMediaType(mediaType)) {
    return typeof response.blob === "function" ? response.blob() : response.text();
  }

  const raw = await response.text();
  const normalized = stripBom(raw);
  const trimmed = normalized.trim();

  if (trimmed === "") {
    return null;
  }

  // Try to parse as JSON if it looks like JSON
  if (isJsonMediaType(mediaType) || looksLikeJson(normalized)) {
    try {
      return JSON.parse(normalized);
    } catch {
      // If JSON parsing fails, return raw text
      return raw;
    }
  }

  return raw;
}

/**
 * Infer response type from Content-Type header
 * Falls back to text if media type is unknown
 */
function inferResponseType(response: Response): "json" | "text" | "blob" {
  const mediaType = getMediaType(response.headers);

  if (isJsonMediaType(mediaType)) return "json";
  if (isTextMediaType(mediaType) || mediaType == null) return "text";
  return "blob";
}

/**
 * Parse successful response body based on requested type
 * Handles empty bodies for status codes that shouldn't have content
 */
async function parseSuccessBody(
  response: Response,
  responseType: "json" | "text" | "blob" | "auto",
  requestInfo: { method: string; url: string },
): Promise<unknown> {
  if (hasNoBody(response, requestInfo.method)) {
    return null;
  }

  const effectiveType =
    responseType === "auto" ? inferResponseType(response) : responseType;

  switch (effectiveType) {
    case "json":
      return parseJsonBody(response, requestInfo);

    case "text": {
      const text = await response.text();
      return text === "" ? null : text;
    }

    case "blob": {
      if (typeof response.blob !== "function") {
        throw new TypeError(
          "Blob responses are not supported in this runtime. " +
            "Use responseType \"json\" or \"text\" instead.",
        );
      }
      return response.blob();
    }
  }
}

// ============================================================================
// Main Fetch Function
// ============================================================================

/**
 * Type-safe fetch wrapper with automatic parsing, auth, and error handling
 *
 * @param input - URL string, URL object, or Request object
 * @param options - Fetch options with additional responseType property
 * @returns Parsed response data
 * @throws ApiError for HTTP error responses (status >= 400)
 * @throws ResponseParseError if response body parsing fails
 * @throws TypeError for invalid requests
 *
 * @example
 * // Simple GET
 * const incidents = await customFetch<Incident[]>('/api/incidents');
 *
 * // POST with body
 * const newIncident = await customFetch<Incident>('/api/incidents', {
 *   method: 'POST',
 *   body: JSON.stringify({ title: 'Database down', severity: 'critical' }),
 *   headers: { 'Content-Type': 'application/json' },
 * });
 *
 * // With custom response type
 * const csvData = await customFetch('/api/export', {
 *   responseType: 'text',
 * });
 *
 * // Error handling
 * try {
 *   await customFetch('/api/resource');
 * } catch (error) {
 *   if (error instanceof ApiError) {
 *     console.error(`HTTP ${error.status}: ${error.message}`);
 *     console.log('Error data:', error.data);
 *   }
 * }
 */
export async function customFetch<T = unknown>(
  input: RequestInfo | URL,
  options: CustomFetchOptions = {},
): Promise<T> {
  // Apply base URL to relative paths
  input = applyBaseUrl(input);
  const { responseType = "auto", headers: headersInit, ...init } = options;

  // Resolve HTTP method
  const method = resolveMethod(input, init.method);

  // Validate that GET/HEAD requests don't have bodies
  if (init.body != null && (method === "GET" || method === "HEAD")) {
    throw new TypeError(`customFetch: ${method} requests cannot have a body.`);
  }

  // Merge headers from Request object and options
  const headers = mergeHeaders(isRequest(input) ? input.headers : undefined, headersInit);

  // Auto-detect JSON content type if body looks like JSON
  if (
    typeof init.body === "string" &&
    !headers.has("content-type") &&
    looksLikeJson(init.body)
  ) {
    headers.set("content-type", "application/json");
  }

  // Set default Accept header for JSON responses
  if (responseType === "json" && !headers.has("accept")) {
    headers.set("accept", DEFAULT_JSON_ACCEPT);
  }

  // Attach bearer token if auth getter is configured
  if (_authTokenGetter && !headers.has("authorization")) {
    const token = await _authTokenGetter();
    if (token) {
      headers.set("authorization", `Bearer ${token}`);
    }
  }

  // Capture request info for error reporting
  const requestInfo = { method, url: resolveUrl(input) };

  // Execute fetch
  const response = await fetch(input, { ...init, method, headers });

  // Handle error responses
  if (!response.ok) {
    const errorData = await parseErrorBody(response, method);
    throw new ApiError(response, errorData, requestInfo);
  }

  // Parse and return success response
  return (await parseSuccessBody(response, responseType, requestInfo)) as T;
}
