import { useEffect, useRef, useState } from "react";
import { useGetLogs } from "@workspace/api-client-react";
import { useWebSocket } from "@/hooks/use-websocket";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TerminalSquare, Circle } from "lucide-react";

type Severity = "INFO" | "WARN" | "ERROR" | "CRITICAL";

const SEV_STYLES: Record<Severity, { color: string; bg: string; label: string }> = {
  INFO:     { color: "#60a5fa", bg: "#1e3a5f20", label: "INF" },
  WARN:     { color: "#fbbf24", bg: "#78350f20", label: "WRN" },
  ERROR:    { color: "#f87171", bg: "#450a0a20", label: "ERR" },
  CRITICAL: { color: "#ef4444", bg: "#450a0a40", label: "CRT" },
};

type LogEntry = {
  id: string;
  timestamp: string;
  severity: Severity;
  service: string;
  message: string;
};

const MAX_LOGS = 200;

export default function Logs() {
  const [liveLogs, setLiveLogs] = useState<LogEntry[]>([]);
  const [filterSeverity, setFilterSeverity] = useState<string>("all");
  const [filterService, setFilterService] = useState<string>("all");
  const [isPaused, setIsPaused] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const { lastMessage, isConnected } = useWebSocket();

  const { data: initialLogs } = useGetLogs({ limit: 80 });

  useEffect(() => {
    if (initialLogs && liveLogs.length === 0) {
      setLiveLogs(initialLogs as LogEntry[]);
    }
  }, [initialLogs]);

  useEffect(() => {
    if (lastMessage?.type === "log" && !isPaused) {
      setLiveLogs(prev => {
        const next = [...prev, lastMessage.payload as LogEntry];
        return next.slice(-MAX_LOGS);
      });
    }
  }, [lastMessage, isPaused]);

  useEffect(() => {
    if (!isPaused && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [liveLogs, isPaused]);

  const services = Array.from(new Set(liveLogs.map(l => l.service))).sort();

  const filtered = liveLogs.filter(l => {
    if (filterSeverity !== "all" && l.severity !== filterSeverity) return false;
    if (filterService !== "all" && l.service !== filterService) return false;
    return true;
  });

  const criticalCount = liveLogs.filter(l => l.severity === "CRITICAL").length;
  const errorCount = liveLogs.filter(l => l.severity === "ERROR").length;

  return (
    <div className="space-y-4 h-full flex flex-col">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <TerminalSquare className="w-6 h-6 text-primary" />
            Live Log Stream
          </h1>
          <div className="flex items-center gap-4 mt-1">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Circle className={`w-2 h-2 fill-current ${isConnected ? "text-green-500" : "text-red-500"}`} />
              {isConnected ? "WebSocket connected" : "Reconnecting..."}
            </div>
            {criticalCount > 0 && <Badge variant="destructive" className="text-xs animate-pulse">{criticalCount} CRITICAL</Badge>}
            {errorCount > 0 && <Badge variant="outline" className="text-xs border-red-500 text-red-400">{errorCount} ERROR</Badge>}
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Select value={filterSeverity} onValueChange={setFilterSeverity}>
            <SelectTrigger className="w-32 h-8 text-xs bg-card border-border">
              <SelectValue placeholder="Severity" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Levels</SelectItem>
              <SelectItem value="INFO">INFO</SelectItem>
              <SelectItem value="WARN">WARN</SelectItem>
              <SelectItem value="ERROR">ERROR</SelectItem>
              <SelectItem value="CRITICAL">CRITICAL</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterService} onValueChange={setFilterService}>
            <SelectTrigger className="w-36 h-8 text-xs bg-card border-border">
              <SelectValue placeholder="Service" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Services</SelectItem>
              {services.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
          <button
            className={`px-3 py-1.5 text-xs rounded border font-mono transition-colors ${isPaused ? "border-yellow-500 text-yellow-400 bg-yellow-500/10" : "border-border text-muted-foreground hover:border-primary hover:text-primary"}`}
            onClick={() => setIsPaused(p => !p)}
          >
            {isPaused ? "▶ RESUME" : "⏸ PAUSE"}
          </button>
        </div>
      </div>

      <Card className="flex-1 bg-[#050d18] border-border overflow-hidden font-mono">
        <CardHeader className="py-2 px-4 border-b border-border/50 bg-card/30">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className="text-green-400">●</span>
            <span>inferops-log-stream</span>
            <span className="ml-auto">{filtered.length} entries</span>
          </div>
        </CardHeader>
        <CardContent className="p-0 h-full">
          <div
            ref={scrollRef}
            className="h-full overflow-y-auto p-3 space-y-0.5"
            style={{ maxHeight: "calc(100vh - 280px)" }}
          >
            {filtered.length === 0 && (
              <div className="text-center text-muted-foreground text-sm py-12">
                <TerminalSquare className="w-8 h-8 mx-auto mb-3 opacity-30" />
                Waiting for log stream...
              </div>
            )}
            {filtered.map((log, i) => {
              const style = SEV_STYLES[log.severity] ?? SEV_STYLES.INFO;
              const isCritical = log.severity === "CRITICAL";
              return (
                <div
                  key={log.id ?? i}
                  className={`flex gap-3 text-xs py-0.5 px-2 rounded transition-all ${isCritical ? "animate-pulse" : ""}`}
                  style={{ backgroundColor: style.bg }}
                >
                  <span className="text-muted-foreground/60 shrink-0 tabular-nums">
                    {new Date(log.timestamp).toLocaleTimeString("en-US", { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                  </span>
                  <span
                    className="shrink-0 w-10 font-bold text-center"
                    style={{ color: style.color }}
                  >
                    {style.label}
                  </span>
                  <span className="shrink-0 w-28 text-muted-foreground/80 truncate">
                    [{log.service}]
                  </span>
                  <span
                    className="flex-1"
                    style={{ color: log.severity === "INFO" ? "#94a3b8" : style.color }}
                  >
                    {log.message}
                  </span>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
