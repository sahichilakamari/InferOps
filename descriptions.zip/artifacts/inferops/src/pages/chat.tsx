import { useState, useRef, useEffect } from "react";
import { useChatWithInfra } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { MessageSquare, Send, Bot, User, Loader2, Terminal } from "lucide-react";

type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
};

const SUGGESTED_QUESTIONS = [
  "Why is checkout failing?",
  "What caused the last outage?",
  "Which services are affected?",
  "How do we fix this?",
  "What changed before the failure?",
  "Generate a rollback plan",
];

export default function Chat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const chatMutation = useChatWithInfra();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async (text?: string) => {
    const messageText = text ?? input.trim();
    if (!messageText || isStreaming) return;

    setInput("");
    const userMsg: Message = {
      id: crypto.randomUUID(),
      role: "user",
      content: messageText,
      createdAt: new Date().toISOString(),
    };
    setMessages(prev => [...prev, userMsg]);
    setIsStreaming(true);

    try {
      const response = await chatMutation.mutateAsync({
        data: { message: messageText, conversationId },
      });
      if (response.conversationId) {
        setConversationId(response.conversationId);
      }
      setMessages(prev => [...prev, {
        id: response.id,
        role: "assistant",
        content: response.message,
        createdAt: response.createdAt,
      }]);
    } catch {
      setMessages(prev => [...prev, {
        id: crypto.randomUUID(),
        role: "assistant",
        content: "Error reaching AI backend. Check that the API server is running and OPENAI_API_KEY is configured.",
        createdAt: new Date().toISOString(),
      }]);
    } finally {
      setIsStreaming(false);
      inputRef.current?.focus();
    }
  };

  return (
    <div className="flex flex-col h-full space-y-4">
      <div>
        <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <MessageSquare className="w-6 h-6 text-primary" />
          Talk to Your Infrastructure
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          AI-powered SRE copilot with real-time access to your system state
        </p>
      </div>

      <div className="flex flex-1 gap-4 overflow-hidden" style={{ maxHeight: "calc(100vh - 220px)" }}>
        {/* Chat panel */}
        <div className="flex-1 flex flex-col overflow-hidden">
          <Card className="flex-1 bg-[#050d18] border-border overflow-hidden flex flex-col">
            {/* Terminal header */}
            <div className="flex items-center gap-2 px-4 py-2 border-b border-border/50 bg-card/30">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500/60" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
                <div className="w-3 h-3 rounded-full bg-green-500/60" />
              </div>
              <span className="text-xs text-muted-foreground font-mono ml-2">inferops-copilot — SRE AI Assistant</span>
              <div className="ml-auto flex items-center gap-1.5 text-xs text-green-400">
                <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                online
              </div>
            </div>

            <CardContent className="flex-1 overflow-y-auto p-4 space-y-4 font-mono text-sm">
              {messages.length === 0 && (
                <div className="text-center py-12 space-y-3">
                  <Bot className="w-12 h-12 mx-auto text-primary/40" />
                  <p className="text-muted-foreground text-sm">
                    InferOps AI has real-time access to your infrastructure.<br />
                    Ask anything about your systems.
                  </p>
                </div>
              )}

              {messages.map(msg => (
                <div key={msg.id} className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}>
                  <div className={`w-7 h-7 rounded shrink-0 flex items-center justify-center text-xs ${
                    msg.role === "assistant" ? "bg-primary/20 text-primary" : "bg-muted text-foreground"
                  }`}>
                    {msg.role === "assistant" ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                  </div>
                  <div className={`flex-1 rounded-lg p-3 text-xs leading-relaxed ${
                    msg.role === "assistant"
                      ? "bg-card/50 border border-primary/20 text-foreground"
                      : "bg-primary/10 border border-primary/30 text-primary"
                  }`}>
                    <div className="whitespace-pre-wrap">{msg.content}</div>
                    <div className="text-muted-foreground/50 text-xs mt-1">
                      {new Date(msg.createdAt).toLocaleTimeString()}
                    </div>
                  </div>
                </div>
              ))}

              {isStreaming && (
                <div className="flex gap-3">
                  <div className="w-7 h-7 rounded shrink-0 flex items-center justify-center bg-primary/20 text-primary">
                    <Bot className="w-4 h-4" />
                  </div>
                  <div className="bg-card/50 border border-primary/20 rounded-lg p-3 text-xs flex items-center gap-2">
                    <Loader2 className="w-3 h-3 animate-spin text-primary" />
                    <span className="text-muted-foreground animate-pulse">Analyzing infrastructure state...</span>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </CardContent>

            {/* Input */}
            <div className="border-t border-border/50 p-3 bg-card/20">
              <div className="flex gap-2">
                <div className="flex-1 flex items-center gap-2 bg-background border border-border rounded px-3 h-9 text-xs font-mono">
                  <Terminal className="w-3 h-3 text-primary shrink-0" />
                  <input
                    ref={inputRef}
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && sendMessage()}
                    placeholder="Ask about your infrastructure..."
                    className="flex-1 bg-transparent outline-none text-foreground placeholder:text-muted-foreground/50"
                    disabled={isStreaming}
                  />
                </div>
                <button
                  onClick={() => sendMessage()}
                  disabled={!input.trim() || isStreaming}
                  className="h-9 w-9 flex items-center justify-center bg-primary text-primary-foreground rounded disabled:opacity-40 hover:bg-primary/90 transition-colors"
                >
                  {isStreaming ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </Card>
        </div>

        {/* Suggested questions sidebar */}
        <div className="w-56 flex-shrink-0 space-y-3">
          <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Quick Queries</div>
          <div className="space-y-2">
            {SUGGESTED_QUESTIONS.map(q => (
              <button
                key={q}
                onClick={() => sendMessage(q)}
                disabled={isStreaming}
                className="w-full text-left p-2.5 text-xs rounded border border-border bg-card/50 hover:border-primary/50 hover:bg-primary/5 transition-colors text-muted-foreground hover:text-foreground disabled:opacity-50 font-mono"
              >
                {q}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
