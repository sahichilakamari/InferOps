import { useState } from "react";
import { useLocation } from "wouter";
import {
  useListIncidents,
  useTriggerDemoScenario,
  useTriggerIncidentAnalysis,
  getGetDashboardSummaryQueryKey,
  getListIncidentsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, CheckCircle2, Clock, Zap, Loader2, ChevronRight, Filter } from "lucide-react";

type SeverityFilter = "all" | "critical" | "high" | "medium" | "low";
type StatusFilter = "all" | "active" | "acknowledged" | "resolved";

const SEV_COLORS: Record<string, string> = {
  critical: "border-red-500/60 text-red-400 bg-red-500/10",
  high:     "border-orange-500/60 text-orange-400 bg-orange-500/10",
  medium:   "border-yellow-500/60 text-yellow-400 bg-yellow-500/10",
  low:      "border-blue-500/60 text-blue-400 bg-blue-500/10",
};

const STATUS_COLORS: Record<string, string> = {
  active:       "border-red-500/50 text-red-400 bg-red-500/10",
  acknowledged: "border-yellow-500/50 text-yellow-400 bg-yellow-500/10",
  resolved:     "border-green-500/50 text-green-400 bg-green-500/10",
};

function timeAgo(date: string) {
  const secs = Math.floor((Date.now() - new Date(date).getTime()) / 1000);
  if (secs < 60) return `${secs}s ago`;
  if (secs < 3600) return `${Math.floor(secs / 60)}m ago`;
  if (secs < 86400) return `${Math.floor(secs / 3600)}h ago`;
  return `${Math.floor(secs / 86400)}d ago`;
}

function duration(start: string, end?: string | null) {
  const ms = new Date(end ?? new Date()).getTime() - new Date(start).getTime();
  const mins = Math.floor(ms / 60000);
  if (mins < 60) return `${mins}m`;
  return `${Math.floor(mins / 60)}h ${mins % 60}m`;
}

export default function Incidents() {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const [sevFilter, setSevFilter] = useState<SeverityFilter>("all");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [demoPhase, setDemoPhase] = useState<"idle" | "running">("idle");

  const { data: incidents, isLoading } = useListIncidents(
    {},
    { query: { queryKey: getListIncidentsQueryKey(), refetchInterval: 5000 } }
  );

  const triggerDemo = useTriggerDemoScenario();
  const triggerAnalysis = useTriggerIncidentAnalysis();

  const filtered = (incidents ?? []).filter(inc => {
    if (sevFilter !== "all" && inc.severity !== sevFilter) return false;
    if (statusFilter !== "all" && inc.status !== statusFilter) return false;
    return true;
  });

  const active = (incidents ?? []).filter(i => i.status === "active").length;
  const critical = (incidents ?? []).filter(i => i.severity === "critical").length;
  const resolved = (incidents ?? []).filter(i => i.status === "resolved").length;

  const handleDemo = async () => {
    setDemoPhase("running");
    try {
      const scenario = await triggerDemo.mutateAsync();
      if (scenario.incidentId) {
        triggerAnalysis.mutate({ id: scenario.incidentId });
        queryClient.invalidateQueries({ queryKey: getListIncidentsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
        await new Promise(r => setTimeout(r, 800));
        navigate(`/incidents/${scenario.incidentId}`);
      }
    } finally {
      setDemoPhase("idle");
    }
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Incidents</h1>
          <p className="text-xs text-muted-foreground mt-1 font-mono">
            {(incidents ?? []).length} total — updates every 5s
          </p>
        </div>
        <button
          onClick={handleDemo}
          disabled={demoPhase !== "idle"}
          className="flex items-center gap-2 px-4 py-2 rounded-md text-sm font-mono border border-primary/60 bg-primary/10 text-primary hover:bg-primary/20 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {demoPhase === "running"
            ? <Loader2 className="w-4 h-4 animate-spin" />
            : <Zap className="w-4 h-4" />}
          {demoPhase === "running" ? "Running demo..." : "▶ Run Demo Scenario"}
        </button>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Active", value: active, color: "text-destructive", icon: <AlertTriangle className="w-4 h-4 text-destructive" /> },
          { label: "Critical", value: critical, color: "text-red-400", icon: <AlertTriangle className="w-4 h-4 text-red-400" /> },
          { label: "Resolved", value: resolved, color: "text-green-400", icon: <CheckCircle2 className="w-4 h-4 text-green-400" /> },
        ].map(s => (
          <div key={s.label} className="flex items-center gap-3 px-4 py-3 rounded-md border border-border bg-card/50">
            {s.icon}
            <div>
              <div className={`text-xl font-bold font-mono ${s.color}`}>{s.value}</div>
              <div className="text-xs text-muted-foreground">{s.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <Filter className="w-3 h-3" /> Severity:
        </div>
        {(["all", "critical", "high", "medium", "low"] as SeverityFilter[]).map(s => (
          <button
            key={s}
            onClick={() => setSevFilter(s)}
            className={`px-3 py-1 rounded-full text-xs font-mono border transition-colors ${
              sevFilter === s
                ? "border-primary bg-primary/20 text-primary"
                : "border-border text-muted-foreground hover:border-primary/40 hover:text-foreground"
            }`}
          >
            {s}
          </button>
        ))}
        <div className="w-px h-4 bg-border mx-1" />
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          Status:
        </div>
        {(["all", "active", "acknowledged", "resolved"] as StatusFilter[]).map(s => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            className={`px-3 py-1 rounded-full text-xs font-mono border transition-colors ${
              statusFilter === s
                ? "border-primary bg-primary/20 text-primary"
                : "border-border text-muted-foreground hover:border-primary/40 hover:text-foreground"
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      {/* Incidents list */}
      <div className="space-y-2">
        {isLoading ? (
          <div className="flex items-center justify-center py-16 text-muted-foreground gap-3">
            <Loader2 className="w-5 h-5 animate-spin text-primary" />
            <span className="text-sm font-mono">Loading incidents...</span>
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-muted-foreground space-y-3">
            <CheckCircle2 className="w-10 h-10 text-green-500/30" />
            <p className="text-sm">
              {(incidents ?? []).length === 0
                ? "No incidents. System is healthy."
                : "No incidents match your filters."}
            </p>
          </div>
        ) : (
          filtered.map(inc => (
            <button
              key={inc.id}
              onClick={() => navigate(`/incidents/${inc.id}`)}
              className="w-full flex items-center gap-4 px-4 py-3 rounded-md border border-border bg-card/50 hover:border-primary/40 hover:bg-primary/5 transition-all text-left group"
            >
              {/* Severity dot */}
              <div className={`w-2 h-2 rounded-full shrink-0 ${
                inc.severity === "critical" ? "bg-red-500 animate-pulse" :
                inc.severity === "high" ? "bg-orange-500" :
                inc.severity === "medium" ? "bg-yellow-500" : "bg-blue-500"
              }`} />

              {/* ID */}
              <span className="text-xs font-mono text-muted-foreground shrink-0 w-16">
                INC-{inc.id.toString().padStart(4, "0")}
              </span>

              {/* Title */}
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate">{inc.title}</div>
                {inc.affectedServices.length > 0 && (
                  <div className="text-xs text-muted-foreground mt-0.5 truncate">
                    {inc.affectedServices.join(" · ")}
                  </div>
                )}
              </div>

              {/* Badges */}
              <div className="flex items-center gap-2 shrink-0">
                <Badge variant="outline" className={`text-xs uppercase font-mono ${SEV_COLORS[inc.severity] ?? ""}`}>
                  {inc.severity}
                </Badge>
                <Badge variant="outline" className={`text-xs uppercase font-mono ${STATUS_COLORS[inc.status] ?? ""}`}>
                  {inc.status}
                </Badge>
              </div>

              {/* Duration + time */}
              <div className="text-right shrink-0 w-20">
                <div className="flex items-center gap-1 text-xs text-muted-foreground justify-end">
                  <Clock className="w-3 h-3" />
                  {duration(inc.startedAt, inc.resolvedAt)}
                </div>
                <div className="text-xs text-muted-foreground/60 mt-0.5 font-mono">
                  {timeAgo(inc.startedAt)}
                </div>
              </div>

              <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors shrink-0" />
            </button>
          ))
        )}
      </div>
    </div>
  );
}
