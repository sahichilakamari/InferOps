import { useEffect, useRef, useState } from "react";
import { useGetTopology } from "@workspace/api-client-react";
import { useWebSocket } from "@/hooks/use-websocket";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Network, RefreshCw } from "lucide-react";

type NodeStatus = "healthy" | "degraded" | "down" | "unknown";

const STATUS_COLORS: Record<NodeStatus, { stroke: string; fill: string; glow: string; text: string }> = {
  healthy:  { stroke: "#22c55e", fill: "#052e16", glow: "#22c55e40", text: "#22c55e" },
  degraded: { stroke: "#eab308", fill: "#1c1708", glow: "#eab30840", text: "#eab308" },
  down:     { stroke: "#ef4444", fill: "#1f0606", glow: "#ef444440", text: "#ef4444" },
  unknown:  { stroke: "#6b7280", fill: "#111827", glow: "#6b728040", text: "#6b7280" },
};

const TYPE_ICONS: Record<string, string> = {
  web: "⬡",
  gateway: "◇",
  service: "○",
  cache: "▣",
  database: "▤",
};

export default function Topology() {
  const { data: topology, isLoading, refetch } = useGetTopology();
  const { lastMessage } = useWebSocket();
  const [serviceStatuses, setServiceStatuses] = useState<Record<string, NodeStatus>>({});
  const [pulsingNodes, setPulsingNodes] = useState<Set<string>>(new Set());
  const animRef = useRef<number>(0);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    if (lastMessage?.type === "metrics") {
      const services: { id: string; status: NodeStatus }[] = lastMessage.payload.services ?? [];
      setServiceStatuses(Object.fromEntries(services.map((s) => [s.id, s.status])));
      const down = services.filter(s => s.status === "down" || s.status === "degraded").map(s => s.id);
      if (down.length > 0) setPulsingNodes(new Set(down));
    }
    if (lastMessage?.type === "alert") {
      const svc = lastMessage.payload.service;
      if (svc) setPulsingNodes(prev => new Set([...prev, svc]));
    }
  }, [lastMessage]);

  useEffect(() => {
    const interval = setInterval(() => setTick(t => t + 1), 1200);
    return () => clearInterval(interval);
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <RefreshCw className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  const nodes = topology?.nodes ?? [];
  const edges = topology?.edges ?? [];

  const getStatus = (nodeId: string): NodeStatus => serviceStatuses[nodeId] ?? (nodes.find(n => n.id === nodeId)?.status as NodeStatus) ?? "healthy";

  const getNodeXY = (nodeId: string) => {
    const n = nodes.find(n => n.id === nodeId);
    return { x: n?.x ?? 0, y: n?.y ?? 0 };
  };

  const getEdgeColor = (source: string, target: string) => {
    const ss = getStatus(source);
    const ts = getStatus(target);
    if (ss === "down" || ts === "down") return "#ef4444";
    if (ss === "degraded" || ts === "degraded") return "#eab308";
    return "#22c55e40";
  };

  return (
    <div className="space-y-4 h-full flex flex-col">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Network className="w-6 h-6 text-primary" />
            Service Topology
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Live dependency graph — failures cascade visually</p>
        </div>
        <div className="flex gap-3">
          {[
            { status: "healthy" as NodeStatus, label: "Healthy" },
            { status: "degraded" as NodeStatus, label: "Degraded" },
            { status: "down" as NodeStatus, label: "Down" },
          ].map(({ status, label }) => (
            <div key={status} className="flex items-center gap-1.5 text-xs">
              <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: STATUS_COLORS[status].stroke }} />
              <span className="text-muted-foreground">{label}</span>
            </div>
          ))}
        </div>
      </div>

      <Card className="flex-1 bg-card/30 border-border overflow-hidden">
        <CardContent className="p-0 h-full relative">
          <svg width="100%" height="100%" viewBox="0 0 800 580" className="w-full h-full" style={{ minHeight: 480 }}>
            <defs>
              {nodes.map(node => {
                const st = getStatus(node.id);
                const col = STATUS_COLORS[st];
                return (
                  <filter key={`glow-${node.id}`} id={`glow-${node.id}`} x="-50%" y="-50%" width="200%" height="200%">
                    <feGaussianBlur stdDeviation={st === "down" ? (tick % 2 === 0 ? "8" : "4") : "5"} result="coloredBlur" />
                    <feMerge>
                      <feMergeNode in="coloredBlur" />
                      <feMergeNode in="SourceGraphic" />
                    </feMerge>
                  </filter>
                );
              })}
            </defs>

            {/* Edges */}
            {edges.map((edge, i) => {
              const s = getNodeXY(edge.source);
              const t = getNodeXY(edge.target);
              const color = getEdgeColor(edge.source, edge.target);
              const isActive = color !== "#22c55e40";
              return (
                <g key={i}>
                  <line
                    x1={s.x} y1={s.y} x2={t.x} y2={t.y}
                    stroke={color}
                    strokeWidth={isActive ? 2 : 1}
                    strokeDasharray={isActive ? "6 4" : "none"}
                    opacity={0.7}
                    style={{ transition: "stroke 0.5s, stroke-width 0.5s" }}
                  />
                  {isActive && (
                    <circle r="3" fill={color} opacity={0.9}>
                      <animateMotion dur="1.5s" repeatCount="indefinite" path={`M${s.x},${s.y} L${t.x},${t.y}`} />
                    </circle>
                  )}
                </g>
              );
            })}

            {/* Nodes */}
            {nodes.map(node => {
              const st = getStatus(node.id);
              const col = STATUS_COLORS[st];
              const isPulsing = pulsingNodes.has(node.id) || st === "down";
              const x = node.x ?? 0;
              const y = node.y ?? 0;

              return (
                <g key={node.id} style={{ cursor: "pointer" }}>
                  {/* Glow background */}
                  <circle
                    cx={x} cy={y} r={isPulsing ? (tick % 2 === 0 ? 44 : 36) : 40}
                    fill={col.glow}
                    opacity={isPulsing ? 0.8 : 0.5}
                    style={{ transition: "r 0.6s ease-in-out, opacity 0.6s ease-in-out" }}
                  />
                  {/* Node circle */}
                  <circle
                    cx={x} cy={y} r={28}
                    fill={col.fill}
                    stroke={col.stroke}
                    strokeWidth={isPulsing ? 2.5 : 1.5}
                    filter={`url(#glow-${node.id})`}
                    style={{ transition: "stroke 0.5s, stroke-width 0.5s" }}
                  />
                  {/* Type icon */}
                  <text x={x} y={y - 2} textAnchor="middle" dominantBaseline="middle" fontSize="16" fill={col.text} opacity={0.7}>
                    {TYPE_ICONS[node.type] ?? "○"}
                  </text>
                  {/* Node name */}
                  <text x={x} y={y + 44} textAnchor="middle" fontSize="11" fill="#e2e8f0" fontFamily="monospace" fontWeight="600">
                    {node.name}
                  </text>
                  {/* Status badge */}
                  <text x={x} y={y + 57} textAnchor="middle" fontSize="9" fill={col.text} fontFamily="monospace">
                    [{st.toUpperCase()}]
                  </text>
                </g>
              );
            })}
          </svg>
        </CardContent>
      </Card>

      {/* Service summary row */}
      <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
        {nodes.map(node => {
          const st = getStatus(node.id);
          const col = STATUS_COLORS[st];
          return (
            <Card key={node.id} className="bg-card/50 border-border" style={{ borderColor: col.stroke + "60" }}>
              <CardContent className="p-3 text-center">
                <div className="text-xs font-mono font-bold" style={{ color: col.text }}>{node.name}</div>
                <Badge variant="outline" className="mt-1 text-xs capitalize" style={{ borderColor: col.stroke, color: col.text }}>
                  {st}
                </Badge>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
