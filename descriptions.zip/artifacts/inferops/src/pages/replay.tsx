import { useParams } from "wouter";
import { useState, useEffect, useRef } from "react";
import {
  useGetIncident,
  useGetIncidentTimeline,
  useGetIncidentAnalysis,
  useStartIncidentReplay,
  useTriggerDemoScenario,
  getGetIncidentQueryKey,
  getGetIncidentTimelineQueryKey,
  getGetIncidentAnalysisQueryKey,
} from "@workspace/api-client-react";
import { useWebSocket } from "@/hooks/use-websocket";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MonitorPlay, Pause, Play, SkipForward, Zap, AlertTriangle, Activity, Radio } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";

type LogEntry = { id: string; timestamp: string; severity: string; service: string; message: string };
type MetricPoint = { time: string; cpu: number; errorRate: number; latency: number };

const SEV_COLOR: Record<string, string> = {
  INFO: "#60a5fa",
  WARN: "#fbbf24",
  ERROR: "#f87171",
  CRITICAL: "#ef4444",
};

export default function Replay() {
  const { id } = useParams<{ id: string }>();
  const incidentId = parseInt(id ?? "1", 10);

  const [isReplaying, setIsReplaying] = useState(false);
  const [replayLogs, setReplayLogs] = useState<LogEntry[]>([]);
  const [metricsHistory, setMetricsHistory] = useState<MetricPoint[]>([]);
  const [currentStep, setCurrentStep] = useState(0);
  const [aiNarration, setAiNarration] = useState<string>("");
  const [showNarration, setShowNarration] = useState(false);
  const [alertBanner, setAlertBanner] = useState<string | null>(null);
  const logsEndRef = useRef<HTMLDivElement>(null);

  const { data: incident } = useGetIncident(incidentId, {
    query: { queryKey: getGetIncidentQueryKey(incidentId), enabled: !!incidentId }
  });
  const { data: timeline } = useGetIncidentTimeline(incidentId, {
    query: { queryKey: getGetIncidentTimelineQueryKey(incidentId), enabled: !!incidentId }
  });
  const { data: analysis } = useGetIncidentAnalysis(incidentId, {
    query: { queryKey: getGetIncidentAnalysisQueryKey(incidentId), enabled: !!incidentId }
  });

  const startReplay = useStartIncidentReplay();
  const { lastMessage } = useWebSocket();

  useEffect(() => {
    if (!isReplaying) return;
    if (lastMessage?.type === "log") {
      setReplayLogs(prev => [...prev, lastMessage.payload].slice(-100));
      setTimeout(() => logsEndRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
    }
    if (lastMessage?.type === "metrics" && lastMessage.payload?.services) {
      const services = lastMessage.payload.services;
      const apiGw = services.find((s: { id: string }) => s.id === "api-gateway");
      const redis = services.find((s: { id: string }) => s.id === "redis");
      setMetricsHistory(prev => [...prev, {
        time: new Date().toLocaleTimeString("en-US", { hour12: false }),
        cpu: apiGw?.cpuUsage ?? 20,
        errorRate: apiGw?.errorRate ?? 0,
        latency: redis?.latencyMs ?? 10,
      }].slice(-30));
    }
    if (lastMessage?.type === "alert") {
      setAlertBanner(lastMessage.payload.message);
      setTimeout(() => setAlertBanner(null), 4000);
    }
  }, [lastMessage, isReplaying]);

  useEffect(() => {
    if (!isReplaying || !timeline || timeline.length === 0) return;
    if (currentStep >= timeline.length) {
      setIsReplaying(false);
      if (analysis) {
        setTimeout(() => {
          setAiNarration(analysis.explanation);
          setShowNarration(true);
        }, 1000);
      }
      return;
    }
    const timer = setTimeout(() => setCurrentStep(s => s + 1), 1800);
    return () => clearTimeout(timer);
  }, [isReplaying, currentStep, timeline?.length]);

  const handleStartReplay = async () => {
    setReplayLogs([]);
    setMetricsHistory([]);
    setCurrentStep(0);
    setShowNarration(false);
    setAiNarration("");
    await startReplay.mutateAsync({ id: incidentId });
    setIsReplaying(true);
  };

  const visibleEvents = timeline?.slice(0, currentStep) ?? [];

  return (
    <div className="space-y-4 h-full flex flex-col">
      {/* Alert banner */}
      {alertBanner && (
        <div className="fixed top-4 right-4 z-50 bg-red-500/90 text-white px-4 py-3 rounded-lg shadow-2xl border border-red-400 text-sm font-medium animate-in slide-in-from-top-2 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 animate-pulse" />
          {alertBanner}
        </div>
      )}

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <MonitorPlay className="w-6 h-6 text-primary" />
            Incident Replay
          </h1>
          {incident && <p className="text-sm text-muted-foreground mt-1 font-mono">{incident.title}</p>}
        </div>
        <div className="flex gap-2">
          {!isReplaying ? (
            <Button onClick={handleStartReplay} disabled={startReplay.isPending} className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2">
              <Play className="w-4 h-4" />
              {currentStep > 0 ? "Replay Again" : "Start Cinematic Replay"}
            </Button>
          ) : (
            <Button variant="outline" onClick={() => setIsReplaying(false)} className="border-yellow-500/50 text-yellow-400 hover:bg-yellow-500/10 gap-2">
              <Pause className="w-4 h-4" />
              Pause Replay
            </Button>
          )}
        </div>
      </div>

      {/* AI Narration */}
      {showNarration && aiNarration && (
        <Card className="bg-primary/5 border-primary/40">
          <CardContent className="p-4 flex gap-3">
            <div className="w-8 h-8 rounded bg-primary/20 flex items-center justify-center shrink-0">
              <Zap className="w-4 h-4 text-primary" />
            </div>
            <div>
              <div className="text-xs font-semibold text-primary uppercase tracking-wider mb-1 flex items-center gap-2">
                <Radio className="w-3 h-3 animate-pulse" /> AI Incident Narration
              </div>
              <p className="text-sm text-foreground leading-relaxed">{aiNarration}</p>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 flex-1">
        {/* Timeline progression */}
        <Card className="bg-card/50 border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Activity className="w-4 h-4 text-primary" />
              Timeline Replay
              {isReplaying && <Badge variant="outline" className="ml-auto text-xs border-red-500 text-red-400 animate-pulse">LIVE</Badge>}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {timeline && timeline.length > 0 ? (
              <div className="relative">
                <div className="absolute left-4 top-0 bottom-0 w-px bg-border/30" />
                {timeline.map((event, i) => {
                  const isVisible = i < currentStep;
                  const isCurrent = i === currentStep - 1;
                  return (
                    <div
                      key={event.id}
                      className={`relative flex gap-4 pb-3 transition-all duration-500 ${isVisible ? "opacity-100" : "opacity-20"}`}
                    >
                      <div className={`relative z-10 w-8 h-8 flex items-center justify-center rounded-full border transition-colors ${
                        isCurrent ? "bg-primary/20 border-primary animate-pulse" : isVisible ? "bg-card border-border" : "bg-card/20 border-border/30"
                      }`}>
                        <AlertTriangle className={`w-3.5 h-3.5 ${isCurrent ? "text-primary" : "text-muted-foreground"}`} />
                      </div>
                      <div className="flex-1 pt-1.5">
                        <p className="text-xs font-medium">{event.message}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-xs text-muted-foreground font-mono">
                            {new Date(event.timestamp).toLocaleTimeString()}
                          </span>
                          {event.service && <Badge variant="outline" className="text-xs py-0 h-4">{event.service}</Badge>}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-xs text-muted-foreground text-center py-6">
                No timeline events. Start the demo scenario first.
              </p>
            )}
          </CardContent>
        </Card>

        <div className="space-y-4">
          {/* Live metrics chart */}
          <Card className="bg-card/50 border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Activity className="w-4 h-4 text-primary" />
                Live Metrics During Replay
              </CardTitle>
            </CardHeader>
            <CardContent>
              {metricsHistory.length > 2 ? (
                <ResponsiveContainer width="100%" height={150}>
                  <LineChart data={metricsHistory}>
                    <XAxis dataKey="time" tick={{ fontSize: 9, fill: "#64748b" }} />
                    <YAxis tick={{ fontSize: 9, fill: "#64748b" }} />
                    <Tooltip
                      contentStyle={{ backgroundColor: "#0f172a", border: "1px solid #1e293b", fontSize: 11 }}
                      labelStyle={{ color: "#94a3b8" }}
                    />
                    <Line type="monotone" dataKey="cpu" stroke="#60a5fa" strokeWidth={2} dot={false} name="CPU %" />
                    <Line type="monotone" dataKey="errorRate" stroke="#f87171" strokeWidth={2} dot={false} name="Error %" />
                    <Line type="monotone" dataKey="latency" stroke="#fbbf24" strokeWidth={1.5} dot={false} name="Latency ms" />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-32 flex items-center justify-center text-xs text-muted-foreground">
                  {isReplaying ? "Collecting metrics..." : "Start replay to see live metrics"}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Live log stream */}
          <Card className="bg-[#050d18] border-border overflow-hidden">
            <CardHeader className="py-2 px-3 border-b border-border/50 bg-card/20">
              <CardTitle className="text-xs font-mono text-muted-foreground flex items-center gap-2">
                replay-log-stream
                {isReplaying && <span className="text-red-400 animate-pulse">● RECORDING</span>}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-2" style={{ maxHeight: 200, overflowY: "auto" }}>
              {replayLogs.length === 0 ? (
                <p className="text-xs text-muted-foreground text-center py-4 font-mono">Waiting for replay...</p>
              ) : (
                <div className="space-y-0.5 font-mono text-xs">
                  {replayLogs.map((log, i) => (
                    <div key={log.id ?? i} className="flex gap-2">
                      <span className="text-muted-foreground/50 tabular-nums shrink-0">
                        {new Date(log.timestamp).toLocaleTimeString("en-US", { hour12: false })}
                      </span>
                      <span className="shrink-0 w-8" style={{ color: SEV_COLOR[log.severity] ?? "#94a3b8" }}>
                        {log.severity.slice(0, 3)}
                      </span>
                      <span className="text-muted-foreground/70 shrink-0 w-24 truncate">[{log.service}]</span>
                      <span style={{ color: log.severity === "INFO" ? "#94a3b8" : SEV_COLOR[log.severity] ?? "#94a3b8" }}>
                        {log.message}
                      </span>
                    </div>
                  ))}
                  <div ref={logsEndRef} />
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
