import { useState } from "react";
import { useLocation } from "wouter";
import {
  useGetDashboardSummary,
  useGetCurrentMetrics,
  useGetMetricsHistory,
  getGetDashboardSummaryQueryKey,
  getGetCurrentMetricsQueryKey,
  getGetMetricsHistoryQueryKey,
  useTriggerDemoScenario,
  useTriggerIncidentAnalysis,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, AlertTriangle, CheckCircle2, ServerCrash, Zap, Loader2, ChevronRight, TrendingUp } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export default function Dashboard() {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const [demoPhase, setDemoPhase] = useState<"idle" | "creating" | "analyzing">("idle");

  const { data: summary } = useGetDashboardSummary({
    query: { queryKey: getGetDashboardSummaryQueryKey(), refetchInterval: 5000 }
  });
  const { data: metrics } = useGetCurrentMetrics({
    query: { queryKey: getGetCurrentMetricsQueryKey(), refetchInterval: 5000 }
  });
  const { data: history } = useGetMetricsHistory(
    { minutes: 30 },
    { query: { queryKey: getGetMetricsHistoryQueryKey({ minutes: 30 }), refetchInterval: 15000 } }
  );

  const triggerDemo = useTriggerDemoScenario();
  const triggerAnalysis = useTriggerIncidentAnalysis();

  const chartData = (history ?? []).map(p => ({
    t: new Date(p.timestamp).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false }),
    cpu: Math.round(p.cpuUsage),
    err: parseFloat(p.errorRate.toFixed(2)),
    lat: Math.round(p.latencyMs),
  }));

  const handleDemoMode = async () => {
    try {
      setDemoPhase("creating");
      const scenario = await triggerDemo.mutateAsync();
      const incidentId = scenario.incidentId;
      if (!incidentId) { setDemoPhase("idle"); return; }
      queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
      setDemoPhase("analyzing");
      triggerAnalysis.mutate({ id: incidentId });
      await new Promise(r => setTimeout(r, 900));
      navigate(`/incidents/${incidentId}`);
    } catch {
      setDemoPhase("idle");
    }
  };

  const demoLabel =
    demoPhase === "creating" ? "Creating incident..." :
    demoPhase === "analyzing" ? "Running AI analysis..." :
    "▶  Run Demo Scenario";

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">System Status</h1>
          <p className="text-xs text-muted-foreground mt-1 font-mono">Live telemetry — updates every 5s</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleDemoMode}
            disabled={demoPhase !== "idle"}
            className={`relative flex items-center gap-2 px-4 py-2 rounded-md text-sm font-mono font-medium border transition-all duration-200
              ${demoPhase !== "idle"
                ? "border-primary/40 bg-primary/5 text-primary/60 cursor-not-allowed"
                : "border-primary/60 bg-primary/10 text-primary hover:bg-primary/20 hover:border-primary cursor-pointer"
              }`}
          >
            {demoPhase !== "idle"
              ? <Loader2 className="w-4 h-4 animate-spin" />
              : <Zap className="w-4 h-4" />}
            {demoLabel}
            {demoPhase !== "idle" && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-primary animate-ping" />
            )}
          </button>
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full bg-green-500 animate-pulse" />
            <span className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Live</span>
          </div>
        </div>
      </div>

      {/* Demo banner */}
      {demoPhase !== "idle" && (
        <div className="flex items-start gap-3 px-4 py-3 rounded-md border border-primary/30 bg-primary/5 text-sm">
          <Zap className="w-4 h-4 text-primary shrink-0 mt-0.5 animate-pulse" />
          <div>
            <div className="font-medium text-primary text-xs uppercase tracking-wider">Demo Mode Active</div>
            <div className="text-muted-foreground text-xs font-mono mt-0.5">
              Triggering Redis connection pool exhaustion → cascading auth failure → full outage. AI RCA running in parallel.
            </div>
          </div>
        </div>
      )}

      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: "Active Incidents", value: summary?.activeIncidents ?? 0, icon: <AlertTriangle className="h-4 w-4 text-destructive" />, color: (summary?.activeIncidents ?? 0) > 0 ? "text-destructive" : "text-foreground" },
          { label: "Services Down", value: summary?.downServices ?? 0, icon: <ServerCrash className="h-4 w-4 text-orange-500" />, color: "text-orange-500" },
          { label: "Healthy Services", value: summary?.healthyServices ?? 0, icon: <CheckCircle2 className="h-4 w-4 text-green-500" />, color: "text-green-500" },
          { label: "Avg Latency", value: summary?.avgLatencyMs ? `${Math.round(summary.avgLatencyMs)}ms` : "—", icon: <Activity className="h-4 w-4 text-blue-500" />, color: "text-blue-500" },
        ].map(s => (
          <Card key={s.label} className="bg-card/50 border-border">
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium text-muted-foreground">{s.label}</CardTitle>
              {s.icon}
            </CardHeader>
            <CardContent>
              <div className={`text-3xl font-bold ${s.color}`}>{s.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Metrics sparkline chart */}
      {chartData.length > 2 && (
        <Card className="bg-card/50 border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" />
              Infrastructure Trend — Last 30 Minutes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={140}>
              <AreaChart data={chartData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="gCpu" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#60a5fa" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#60a5fa" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="gErr" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f87171" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#f87171" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="gLat" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#fbbf24" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#fbbf24" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="t" tick={{ fontSize: 9, fill: "#64748b" }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
                <YAxis tick={{ fontSize: 9, fill: "#64748b" }} tickLine={false} axisLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#0a1628", border: "1px solid #1e293b", fontSize: 11, borderRadius: 4 }}
                  labelStyle={{ color: "#94a3b8", marginBottom: 4 }}
                  itemStyle={{ padding: "1px 0" }}
                />
                <Area type="monotone" dataKey="cpu" stroke="#60a5fa" strokeWidth={1.5} fill="url(#gCpu)" dot={false} name="CPU %" />
                <Area type="monotone" dataKey="err" stroke="#f87171" strokeWidth={1.5} fill="url(#gErr)" dot={false} name="Error %" />
                <Area type="monotone" dataKey="lat" stroke="#fbbf24" strokeWidth={1} fill="url(#gLat)" dot={false} name="Latency ms" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Recent Incidents */}
        <Card className="bg-card/50 border-border">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Recent Incidents
              {(summary?.recentIncidents?.length ?? 0) > 0 && (
                <span className="text-xs text-muted-foreground font-normal font-mono">
                  {summary!.recentIncidents.length} total
                </span>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {summary?.recentIncidents?.map(inc => (
                <button
                  key={inc.id}
                  onClick={() => navigate(`/incidents/${inc.id}`)}
                  className="w-full flex items-center justify-between p-3 bg-muted/50 rounded-md border border-border/50 hover:border-primary/40 hover:bg-primary/5 transition-colors text-left group"
                >
                  <div className="min-w-0 flex-1">
                    <div className="font-medium text-sm truncate">{inc.title}</div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      Severity:{" "}
                      <span className={`uppercase font-mono ${
                        inc.severity === "critical" ? "text-red-400" :
                        inc.severity === "high" ? "text-orange-400" :
                        inc.severity === "medium" ? "text-yellow-400" : "text-blue-400"
                      }`}>{inc.severity}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0 ml-3">
                    <div className={`text-xs uppercase px-2 py-1 rounded font-mono ${
                      inc.status === "active" ? "bg-destructive/20 text-destructive" :
                      inc.status === "acknowledged" ? "bg-yellow-500/20 text-yellow-400" :
                      "bg-green-500/20 text-green-400"
                    }`}>
                      {inc.status}
                    </div>
                    <ChevronRight className="w-3 h-3 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                </button>
              ))}
              {(!summary?.recentIncidents || summary.recentIncidents.length === 0) && (
                <div className="text-sm text-muted-foreground text-center py-8 space-y-2">
                  <CheckCircle2 className="w-8 h-8 mx-auto text-green-500/30" />
                  <p>No recent incidents.</p>
                  <p className="text-xs">Click <span className="text-primary font-mono">Run Demo Scenario</span> to simulate an outage.</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Global Metrics */}
        <Card className="bg-card/50 border-border">
          <CardHeader>
            <CardTitle>Global Metrics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-5">
              {[
                { label: "CPU Usage", val: metrics?.globalCpu, color: (metrics?.globalCpu ?? 0) > 80 ? "bg-destructive" : "bg-blue-500" },
                { label: "Memory Usage", val: metrics?.globalMemory, color: (metrics?.globalMemory ?? 0) > 85 ? "bg-destructive" : "bg-purple-500" },
              ].map(m => (
                <div key={m.label}>
                  <div className="flex justify-between mb-1.5">
                    <span className="text-sm font-medium">{m.label}</span>
                    <span className="text-sm text-muted-foreground font-mono">{m.val ? Math.round(m.val) : 0}%</span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-2">
                    <div className={`h-2 rounded-full transition-all duration-700 ${m.color}`} style={{ width: `${Math.min(m.val ?? 0, 100)}%` }} />
                  </div>
                </div>
              ))}
              <div className="pt-4 border-t border-border">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-xs text-muted-foreground mb-1">Error Rate</div>
                    <div className={`text-xl font-mono ${(metrics?.totalErrorRate ?? 0) > 5 ? "text-destructive" : "text-foreground"}`}>
                      {metrics?.totalErrorRate ? metrics.totalErrorRate.toFixed(2) : "0.00"}%
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground mb-1">Requests / Sec</div>
                    <div className="text-xl font-mono">
                      {metrics?.totalRequestsPerSec ? Math.round(metrics.totalRequestsPerSec).toLocaleString() : 0}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
