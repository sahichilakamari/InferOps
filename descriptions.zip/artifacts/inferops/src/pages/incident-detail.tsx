import { useParams } from "wouter";
import {
  useGetIncident,
  useGetIncidentTimeline,
  useGetIncidentAnalysis,
  useGetPostmortem,
  useTriggerIncidentAnalysis,
  useGeneratePostmortem,
  useUpdateIncident,
  getGetIncidentQueryKey,
  getGetIncidentTimelineQueryKey,
  getGetIncidentAnalysisQueryKey,
  getGetPostmortemQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  AlertTriangle, CheckCircle2, Clock, Cpu, Zap, Shield,
  FileText, RefreshCw, ChevronRight, Activity, TrendingUp
} from "lucide-react";

const SEV_COLORS: Record<string, string> = {
  critical: "border-red-500 text-red-400 bg-red-500/10",
  high:     "border-orange-500 text-orange-400 bg-orange-500/10",
  medium:   "border-yellow-500 text-yellow-400 bg-yellow-500/10",
  low:      "border-blue-500 text-blue-400 bg-blue-500/10",
};

const EVENT_ICONS: Record<string, React.ReactNode> = {
  deployment: <Zap className="w-4 h-4 text-blue-400" />,
  spike:      <TrendingUp className="w-4 h-4 text-yellow-400" />,
  failure:    <AlertTriangle className="w-4 h-4 text-red-400" />,
  recovery:   <CheckCircle2 className="w-4 h-4 text-green-400" />,
  alert:      <Activity className="w-4 h-4 text-orange-400" />,
  detection:  <Shield className="w-4 h-4 text-purple-400" />,
};

export default function IncidentDetail() {
  const { id } = useParams<{ id: string }>();
  const incidentId = parseInt(id ?? "0", 10);
  const queryClient = useQueryClient();

  const { data: incident, isLoading } = useGetIncident(incidentId, {
    query: { enabled: !!incidentId, queryKey: getGetIncidentQueryKey(incidentId), refetchInterval: 5000 }
  });
  const { data: timeline } = useGetIncidentTimeline(incidentId, {
    query: { queryKey: getGetIncidentTimelineQueryKey(incidentId), enabled: !!incidentId, refetchInterval: 5000 }
  });
  const { data: analysis, isLoading: analysisLoading } = useGetIncidentAnalysis(incidentId, {
    query: { enabled: !!incidentId, queryKey: getGetIncidentAnalysisQueryKey(incidentId) }
  });
  const { data: postmortem, isLoading: pmLoading } = useGetPostmortem(incidentId, {
    query: { enabled: !!incidentId, queryKey: getGetPostmortemQueryKey(incidentId) }
  });

  const triggerAnalysis = useTriggerIncidentAnalysis();
  const genPostmortem = useGeneratePostmortem();
  const updateIncident = useUpdateIncident();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (!incident) {
    return (
      <div className="text-center py-20 text-muted-foreground">
        <AlertTriangle className="w-12 h-12 mx-auto mb-4 opacity-30" />
        <p>Incident not found</p>
      </div>
    );
  }

  const handleAnalyze = async () => {
    await triggerAnalysis.mutateAsync({ id: incidentId });
    queryClient.invalidateQueries({ queryKey: getGetIncidentAnalysisQueryKey(incidentId) });
  };

  const handlePostmortem = async () => {
    await genPostmortem.mutateAsync({ id: incidentId });
    queryClient.invalidateQueries({ queryKey: getGetPostmortemQueryKey(incidentId) });
  };

  const handleResolve = async () => {
    await updateIncident.mutateAsync({ id: incidentId, data: { status: "resolved" } });
    queryClient.invalidateQueries({ queryKey: getGetIncidentQueryKey(incidentId) });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <Badge variant="outline" className={`text-xs uppercase ${SEV_COLORS[incident.severity] ?? ""}`}>
              {incident.severity}
            </Badge>
            <Badge variant="outline" className="text-xs uppercase">
              {incident.status}
            </Badge>
            <span className="text-xs text-muted-foreground font-mono">INC-{incident.id.toString().padStart(4, "0")}</span>
          </div>
          <h1 className="text-2xl font-bold">{incident.title}</h1>
          {incident.description && <p className="text-muted-foreground mt-1 text-sm">{incident.description}</p>}
          <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
            <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> Started {new Date(incident.startedAt).toLocaleString()}</span>
            {incident.resolvedAt && <span className="flex items-center gap-1 text-green-400"><CheckCircle2 className="w-3 h-3" /> Resolved {new Date(incident.resolvedAt).toLocaleString()}</span>}
          </div>
        </div>
        <div className="flex gap-2 shrink-0">
          {incident.status === "active" && (
            <Button size="sm" variant="outline" onClick={handleResolve} className="border-green-500/50 text-green-400 hover:bg-green-500/10">
              <CheckCircle2 className="w-4 h-4 mr-2" /> Resolve
            </Button>
          )}
          <Button size="sm" variant="outline" onClick={handleAnalyze} disabled={triggerAnalysis.isPending} className="border-primary/50 text-primary hover:bg-primary/10">
            {triggerAnalysis.isPending ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Zap className="w-4 h-4 mr-2" />}
            {analysis ? "Re-Analyze" : "Run AI Analysis"}
          </Button>
          {analysis && (
            <Button size="sm" variant="outline" onClick={handlePostmortem} disabled={genPostmortem.isPending} className="border-border hover:border-primary/50">
              {genPostmortem.isPending ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <FileText className="w-4 h-4 mr-2" />}
              {postmortem ? "Re-generate" : "Generate Postmortem"}
            </Button>
          )}
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Affected Services", value: incident.affectedServices.length.toString(), icon: <Activity className="w-4 h-4 text-orange-400" /> },
          { label: "Error Rate", value: incident.errorRate != null ? `${incident.errorRate.toFixed(1)}%` : "–", icon: <AlertTriangle className="w-4 h-4 text-red-400" /> },
          { label: "Peak CPU", value: incident.peakCpuUsage != null ? `${incident.peakCpuUsage.toFixed(0)}%` : "–", icon: <Cpu className="w-4 h-4 text-yellow-400" /> },
          { label: "Timeline Events", value: (timeline?.length ?? 0).toString(), icon: <Clock className="w-4 h-4 text-blue-400" /> },
        ].map(stat => (
          <Card key={stat.label} className="bg-card/50 border-border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">{stat.label}</span>
                {stat.icon}
              </div>
              <div className="text-2xl font-bold mt-1">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Timeline */}
        <Card className="bg-card/50 border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Clock className="w-4 h-4 text-primary" />
              Incident Timeline
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!timeline || timeline.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-4">No timeline events yet</p>
            ) : (
              <div className="relative space-y-0">
                <div className="absolute left-4 top-0 bottom-0 w-px bg-border/50" />
                {timeline.map((event, i) => (
                  <div key={event.id} className="relative flex gap-4 pb-4">
                    <div className="relative z-10 w-8 h-8 flex items-center justify-center rounded-full bg-card border border-border shrink-0">
                      {EVENT_ICONS[event.eventType] ?? <Activity className="w-4 h-4 text-muted-foreground" />}
                    </div>
                    <div className="flex-1 min-w-0 pt-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-medium">{event.message}</span>
                        {event.service && (
                          <Badge variant="outline" className="text-xs py-0 h-4">{event.service}</Badge>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground mt-0.5 font-mono">
                        {new Date(event.timestamp).toLocaleTimeString()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* AI Analysis */}
        <Card className={`border ${analysis ? "bg-primary/5 border-primary/30" : "bg-card/50 border-border"}`}>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Zap className="w-4 h-4 text-primary" />
              AI Root Cause Analysis
              {analysis && (
                <Badge variant="outline" className="ml-auto text-xs border-primary/50 text-primary">
                  {Math.round((analysis.confidence ?? 0) * 100)}% confidence
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {analysisLoading || triggerAnalysis.isPending ? (
              <div className="flex items-center gap-3 text-sm text-muted-foreground py-4">
                <RefreshCw className="w-5 h-5 animate-spin text-primary" />
                Running AI analysis...
              </div>
            ) : !analysis ? (
              <div className="text-center py-6">
                <Zap className="w-10 h-10 mx-auto mb-3 text-primary/30" />
                <p className="text-sm text-muted-foreground mb-4">Run AI analysis to identify root cause</p>
                <Button size="sm" onClick={handleAnalyze} className="bg-primary text-primary-foreground hover:bg-primary/90">
                  <Zap className="w-4 h-4 mr-2" /> Analyze Now
                </Button>
              </div>
            ) : (
              <div className="space-y-4 text-sm">
                <div>
                  <div className="text-xs font-semibold text-primary uppercase tracking-wider mb-1">Root Cause</div>
                  <p className="text-foreground font-medium">{analysis.rootCause}</p>
                </div>
                <div>
                  <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">Explanation</div>
                  <p className="text-muted-foreground text-xs leading-relaxed">{analysis.explanation}</p>
                </div>
                <div>
                  <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Remediation Steps</div>
                  <ul className="space-y-1.5">
                    {(analysis.remediation ?? []).map((step, i) => (
                      <li key={i} className="flex gap-2 text-xs">
                        <ChevronRight className="w-3 h-3 text-primary shrink-0 mt-0.5" />
                        <span className="text-muted-foreground">{step}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="flex gap-2 flex-wrap">
                  {(analysis.affectedServices ?? []).map(svc => (
                    <Badge key={svc} variant="outline" className="text-xs border-destructive/50 text-destructive">{svc}</Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Postmortem */}
      {postmortem && (
        <Card className="bg-card/50 border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <FileText className="w-4 h-4 text-primary" />
              Postmortem Report
              <span className="ml-auto text-xs text-muted-foreground font-normal">
                {new Date(postmortem.createdAt).toLocaleDateString()}
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
              {[
                { title: "Summary", content: postmortem.summary },
                { title: "Impact", content: postmortem.impact },
                { title: "Resolution", content: postmortem.resolution },
                { title: "Timeline", content: postmortem.timeline },
              ].map(({ title, content }) => (
                <div key={title}>
                  <div className="text-xs font-semibold text-primary uppercase tracking-wider mb-1">{title}</div>
                  <p className="text-muted-foreground text-xs leading-relaxed">{content}</p>
                </div>
              ))}
              <div className="md:col-span-2">
                <div className="text-xs font-semibold text-primary uppercase tracking-wider mb-2">Prevention</div>
                <ul className="space-y-1">
                  {(postmortem.prevention ?? []).map((step, i) => (
                    <li key={i} className="flex gap-2 text-xs">
                      <ChevronRight className="w-3 h-3 text-primary shrink-0 mt-0.5" />
                      <span className="text-muted-foreground">{step}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            {postmortem.markdownContent && (
              <div className="mt-4 pt-4 border-t border-border/50">
                <button className="text-xs text-primary hover:underline font-mono">
                  View full markdown export →
                </button>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
