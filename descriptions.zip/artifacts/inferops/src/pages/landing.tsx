import { Link } from "wouter";
import { Activity, ShieldAlert, Zap, Terminal, ArrowRight, MonitorPlay, MessageSquare } from "lucide-react";
import { useGetDashboardSummary, useGetCurrentMetrics, getGetDashboardSummaryQueryKey, getGetCurrentMetricsQueryKey } from "@workspace/api-client-react";

function LiveStat({ label, value, unit = "" }: { label: string; value?: number | null; unit?: string }) {
  return (
    <div className="flex flex-col items-center gap-1">
      <div className="text-3xl font-black font-mono tabular-nums text-primary">
        {value != null ? (
          <>
            {Number.isInteger(value) ? value.toLocaleString() : value.toFixed(1)}
            <span className="text-lg ml-0.5 text-primary/70">{unit}</span>
          </>
        ) : (
          <span className="text-primary/30 animate-pulse">···</span>
        )}
      </div>
      <div className="text-xs text-muted-foreground uppercase tracking-widest font-mono">{label}</div>
    </div>
  );
}

export default function Landing() {
  const { data: summary } = useGetDashboardSummary({
    query: { queryKey: getGetDashboardSummaryQueryKey(), refetchInterval: 3000 }
  });
  const { data: metrics } = useGetCurrentMetrics({
    query: { queryKey: getGetCurrentMetricsQueryKey(), refetchInterval: 3000 }
  });

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col items-center justify-center font-mono relative overflow-hidden">
      {/* Background grid & glow */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:40px_40px]" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[700px] bg-primary/15 blur-[140px] rounded-full pointer-events-none" />

      <div className="relative z-10 text-center max-w-4xl px-6">
        {/* Status badge */}
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-primary/30 bg-primary/10 text-primary text-xs mb-10">
          <span className="w-1.5 h-1.5 rounded-full bg-primary animate-ping" />
          <Activity className="w-3.5 h-3.5" />
          <span className="tracking-wider">
            {(summary?.activeIncidents ?? 0) > 0
              ? `⚠ ${summary!.activeIncidents} Active Incident${summary!.activeIncidents > 1 ? "s" : ""} Detected`
              : "All Systems Operational"}
          </span>
        </div>

        <h1 className="text-7xl md:text-9xl font-black tracking-tighter mb-6 text-transparent bg-clip-text bg-gradient-to-br from-foreground via-foreground/90 to-muted-foreground">
          INFEROPS
        </h1>
        <p className="text-lg md:text-xl text-muted-foreground mb-12 font-light tracking-wide max-w-2xl mx-auto leading-relaxed">
          The AI Copilot for SRE Teams. Resolve incidents faster with cinematic,
          real-time telemetry and intelligent root cause analysis.
        </p>

        {/* CTA buttons */}
        <div className="flex items-center justify-center gap-3 mb-16">
          <Link href="/dashboard">
            <button className="flex items-center gap-2 h-12 px-7 bg-primary text-primary-foreground hover:bg-primary/90 text-sm font-bold rounded-none border border-primary transition-colors">
              <Zap className="w-4 h-4" />
              Enter Command Center
              <ArrowRight className="w-4 h-4" />
            </button>
          </Link>
          <Link href="/incidents">
            <button className="flex items-center gap-2 h-12 px-7 bg-transparent border border-border text-muted-foreground hover:text-foreground hover:border-primary/50 text-sm font-medium rounded-none transition-colors">
              View Incidents
            </button>
          </Link>
        </div>

        {/* Live stats ticker */}
        <div className="flex items-center justify-center gap-12 p-6 border border-border/50 bg-card/30 backdrop-blur rounded-none mb-4">
          <LiveStat label="Services Online" value={summary?.healthyServices} />
          <div className="w-px h-10 bg-border/50" />
          <LiveStat label="Requests / sec" value={metrics?.totalRequestsPerSec} />
          <div className="w-px h-10 bg-border/50" />
          <LiveStat label="Avg Latency" value={summary?.avgLatencyMs ? Math.round(summary.avgLatencyMs) : null} unit="ms" />
          <div className="w-px h-10 bg-border/50" />
          <LiveStat label="Error Rate" value={metrics?.totalErrorRate} unit="%" />
        </div>
        <div className="flex items-center justify-center gap-1.5 text-xs text-muted-foreground/50">
          <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse inline-block" />
          Live data — updates every 3s
        </div>
      </div>

      {/* Feature cards */}
      <div className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-0 max-w-5xl w-full px-6 relative z-10 border border-border">
        {[
          {
            icon: <ShieldAlert className="w-7 h-7 text-primary mb-4" />,
            title: "Automated RCA",
            desc: "AI instantly analyzes logs, metrics, and traces to pinpoint the exact cause of the outage with confidence scoring.",
            href: "/incidents",
            label: "View Incidents",
          },
          {
            icon: <Activity className="w-7 h-7 text-primary mb-4" />,
            title: "Real-time Telemetry",
            desc: "Live WebSocket streams of your entire infrastructure. Watch cascading failures unfold as they happen.",
            href: "/topology",
            label: "View Topology",
          },
          {
            icon: <MessageSquare className="w-7 h-7 text-primary mb-4" />,
            title: "Infra Copilot",
            desc: "Chat with your infrastructure. Ask \"Why is Redis slow?\" and get instant, contextual answers powered by GPT-4.",
            href: "/chat",
            label: "Open Copilot",
          },
        ].map((card, i) => (
          <Link key={i} href={card.href}>
            <div className={`p-7 bg-card/30 backdrop-blur hover:bg-primary/5 hover:border-primary/30 transition-all cursor-pointer group ${i < 2 ? "border-r border-border" : ""}`}>
              {card.icon}
              <h3 className="text-base font-bold mb-2">{card.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed mb-4">{card.desc}</p>
              <div className="flex items-center gap-1.5 text-xs text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                {card.label} <ArrowRight className="w-3 h-3" />
              </div>
            </div>
          </Link>
        ))}
      </div>

      {/* Bottom bar */}
      <div className="mt-12 flex items-center gap-8 text-xs text-muted-foreground/50 font-mono relative z-10">
        <span>© 2025 InferOps</span>
        <Link href="/replay/1"><span className="flex items-center gap-1 hover:text-muted-foreground cursor-pointer"><MonitorPlay className="w-3 h-3" /> Incident Replay</span></Link>
        <Link href="/logs"><span className="flex items-center gap-1 hover:text-muted-foreground cursor-pointer"><Terminal className="w-3 h-3" /> Live Logs</span></Link>
      </div>
    </div>
  );
}
