import { useEffect, useState, useRef, useCallback } from 'react';

export type WsMessage = {
  type: 'log' | 'metrics' | 'alert' | 'topology' | 'incident';
  payload: any;
};

export function useWebSocket() {
  const [lastMessage, setLastMessage] = useState<WsMessage | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const ws = useRef<WebSocket | null>(null);
  const reconnectTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isMounted = useRef(true);

  const connect = useCallback(() => {
    if (!isMounted.current) return;
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    const wsUrl = `${protocol}//${host}/ws`;

    const socket = new WebSocket(wsUrl);
    ws.current = socket;

    socket.onopen = () => {
      if (isMounted.current) setIsConnected(true);
    };

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (isMounted.current) setLastMessage(data);
      } catch (e) {
        // ignore parse errors
      }
    };

    socket.onclose = () => {
      if (!isMounted.current) return;
      setIsConnected(false);
      // Auto-reconnect after 3s
      reconnectTimer.current = setTimeout(() => {
        if (isMounted.current) connect();
      }, 3000);
    };

    socket.onerror = () => {
      socket.close();
    };
  }, []);

  useEffect(() => {
    isMounted.current = true;
    connect();
    return () => {
      isMounted.current = false;
      if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
      if (ws.current) ws.current.close();
    };
  }, [connect]);

  return { isConnected, lastMessage };
}
