import { useEffect, useRef } from "react";
import { useWebSocket } from "@/hooks/use-websocket";
import { toast } from "@/hooks/use-toast";
import { AlertTriangle, Activity, CheckCircle2, Info } from "lucide-react";

const SEV_MAP: Record<string, { icon: React.ReactNode; className: string; label: string }> = {
  CRITICAL: {
    icon: <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />,
    className: "border-red-500/50 bg-red-500/10",
    label: "CRITICAL",
  },
  ERROR: {
    icon: <AlertTriangle className="w-4 h-4 text-orange-400 shrink-0" />,
    className: "border-orange-500/50 bg-orange-500/10",
    label: "ERROR",
  },
  WARN: {
    icon: <Activity className="w-4 h-4 text-yellow-400 shrink-0" />,
    className: "border-yellow-500/50 bg-yellow-500/10",
    label: "WARN",
  },
  INFO: {
    icon: <Info className="w-4 h-4 text-blue-400 shrink-0" />,
    className: "border-blue-500/30 bg-blue-500/5",
    label: "INFO",
  },
};

export function AlertToasts() {
  const { lastMessage } = useWebSocket();
  const seen = useRef(new Set<string>());

  useEffect(() => {
    if (!lastMessage) return;

    if (lastMessage.type === "alert") {
      const { message, severity = "CRITICAL", service } = lastMessage.payload ?? {};
      if (!message) return;
      const key = `${severity}:${message}`;
      if (seen.current.has(key)) return;
      seen.current.add(key);
      setTimeout(() => seen.current.delete(key), 10000);

      const sev = SEV_MAP[severity] ?? SEV_MAP["INFO"];
      toast({
        duration: 6000,
        description: (
          <div className={`flex items-start gap-3 font-mono`}>
            {sev.icon}
            <div className="min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <span className="text-xs font-bold tracking-widest" style={{
                  color: severity === "CRITICAL" ? "#f87171" : severity === "ERROR" ? "#fb923c" : severity === "WARN" ? "#fbbf24" : "#60a5fa"
                }}>
                  {sev.label}
                </span>
                {service && (
                  <span className="text-xs text-muted-foreground">[{service}]</span>
                )}
              </div>
              <div className="text-xs text-foreground leading-relaxed">{message}</div>
            </div>
          </div>
        ),
      });
    }

    if (lastMessage.type === "incident") {
      const { title, severity } = lastMessage.payload ?? {};
      if (!title) return;
      const key = `incident:${title}`;
      if (seen.current.has(key)) return;
      seen.current.add(key);
      setTimeout(() => seen.current.delete(key), 15000);

      toast({
        duration: 8000,
        description: (
          <div className="flex items-start gap-3 font-mono">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5 animate-pulse" />
            <div>
              <div className="text-xs font-bold text-red-400 tracking-widest mb-0.5">NEW INCIDENT</div>
              <div className="text-xs text-foreground">{title}</div>
              {severity && (
                <div className="text-xs text-muted-foreground mt-0.5 uppercase">Severity: {severity}</div>
              )}
            </div>
          </div>
        ),
      });
    }
  }, [lastMessage]);

  return null;
}
