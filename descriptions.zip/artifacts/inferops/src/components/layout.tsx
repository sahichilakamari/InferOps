import { Link, useLocation } from "wouter";
import { Activity, AlertTriangle, MonitorPlay, Network, TerminalSquare, MessageSquare } from "lucide-react";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  const navItems = [
    { href: "/dashboard", label: "Dashboard", icon: <Activity className="w-4 h-4" /> },
    { href: "/incidents", label: "Incidents", icon: <AlertTriangle className="w-4 h-4" /> },
    { href: "/topology", label: "Topology", icon: <Network className="w-4 h-4" /> },
    { href: "/logs", label: "Logs", icon: <TerminalSquare className="w-4 h-4" /> },
    { href: "/chat", label: "Copilot", icon: <MessageSquare className="w-4 h-4" /> },
    { href: "/replay/1", label: "Replay", icon: <MonitorPlay className="w-4 h-4" /> },
  ];

  if (location === "/") {
    return <div className="min-h-screen bg-background text-foreground">{children}</div>;
  }

  return (
    <div className="flex h-screen overflow-hidden bg-background text-foreground font-mono">
      {/* Sidebar */}
      <aside className="w-64 border-r border-border bg-card/50 backdrop-blur flex flex-col">
        <div className="h-16 flex items-center px-6 border-b border-border">
          <Link href="/" className="flex items-center gap-2 font-bold text-lg text-primary tracking-tighter">
            <Activity className="w-5 h-5" />
            INFEROPS
          </Link>
        </div>
        
        <nav className="flex-1 overflow-y-auto py-4">
          <ul className="space-y-1 px-3">
            {navItems.map((item) => (
              <li key={item.href}>
                <Link href={item.href}>
                  <div className={`flex items-center gap-3 px-3 py-2 text-sm rounded-md transition-colors cursor-pointer ${
                    location.startsWith(item.href) && item.href !== "/" 
                      ? "bg-primary/10 text-primary font-medium" 
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  }`}>
                    {item.icon}
                    {item.label}
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        
        <div className="p-4 border-t border-border">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
            System Online
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto bg-background/95 relative">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none opacity-20"></div>
        <div className="relative z-10 p-6 min-h-full">
          {children}
        </div>
      </main>
    </div>
  );
}
