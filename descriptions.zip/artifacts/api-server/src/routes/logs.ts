import { Router } from "express";
import { db } from "@workspace/db";
import { logEntries } from "@workspace/db";
import { desc, eq } from "drizzle-orm";
import { simulator } from "../lib/simulator";

const router = Router();

// In-memory log buffer for recent logs (fast access)
const recentLogs: { id: string; timestamp: string; severity: string; service: string; message: string }[] = [];
const MAX_BUFFER = 500;

simulator.on("log", (log) => {
  recentLogs.push(log);
  if (recentLogs.length > MAX_BUFFER) recentLogs.shift();
});

// GET /logs
router.get("/", (req, res) => {
  const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
  const severity = req.query.severity as string | undefined;
  const service = req.query.service as string | undefined;

  let filtered = [...recentLogs];
  if (severity) filtered = filtered.filter(l => l.severity === severity);
  if (service) filtered = filtered.filter(l => l.service === service);

  res.json(filtered.slice(-limit).reverse());
});

export default router;
