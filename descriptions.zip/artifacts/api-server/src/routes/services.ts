import { Router } from "express";
import { simulator } from "../lib/simulator";

const router = Router();

// GET /services
router.get("/", (_req, res) => {
  const services = simulator.getServices();
  res.json(services.map(s => ({
    id: s.id,
    name: s.name,
    status: s.status,
    type: s.type,
    errorRate: s.errorRate,
    latencyMs: s.latencyMs,
    cpuUsage: s.cpuUsage,
    memoryUsage: s.memoryUsage,
    requestsPerSec: s.requestsPerSec,
    lastUpdated: new Date().toISOString(),
  })));
});

// GET /services/topology
router.get("/topology", (_req, res) => {
  res.json(simulator.getTopology());
});

export default router;
